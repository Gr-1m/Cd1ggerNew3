#!/bin/sh
# Add your startup script
socat tcp-l:9998,fork exec:./myString,pty,stderr,setsid

# DO NOT DELETE
/etc/init.d/xinetd start;
sleep infinity;
