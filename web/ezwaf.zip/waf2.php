<?php
highlight_file(__FILE__);
define('RUNNING_MAIN_SCRIPT', true);
error_reporting(0);

include_once("flag.php");
// This follow code in That flag.php -- Try to read This variable
// $flag = "flag{This_is_A_fake_flag}";


if (isset($_GET['var']) && $_GET['var']) {
    $cmd = $_GET['var'];

    if (!preg_match("/flag|echo|env|var|eval|sys|file|header/i", $cmd,$match) && strlen($cmd)<30) {
        if (!preg_match("/fl|@|'|,|\^|ag|t\(|tf|[cdesu-z]/i", $cmd, $match) ){
            eval($_GET['var']);
        }
        else die("WAF!!");
    } else{
        die("PLZ DONT HCAK ME😅");
    }
}


?>
