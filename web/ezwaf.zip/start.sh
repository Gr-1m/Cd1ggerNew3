#!/bin/sh
# Add your startup script
mv /var/www/html/index.php /var/www/html/phpinfo.php;

# DO NOT DELETE
/etc/init.d/xinetd start;
sleep infinity;
