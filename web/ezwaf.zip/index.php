<?php
// 重定向到另一个页面
header("Location:waf2.php");
?> 
