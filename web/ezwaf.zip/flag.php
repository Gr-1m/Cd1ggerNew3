<?php

if (defined('RUNNING_MAIN_SCRIPT')) {
    $flag = "赛前flag信息泄露?";

    if (isset($_GET['a'])){
        if (md5($_GET['a'])==="b6517df4721cd242b6a0083672f5b889"){
            echo $flag;
        }
    }else{
        echo "oh~\n";
    }
}else{
    echo "<h1>看什么看? 回去绕waf去!</h1>";
}
?>
